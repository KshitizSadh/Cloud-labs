# ☁️ Cloud Computing Practicals — Complete Documentation

> A comprehensive, hands-on guide to cloud computing covering AWS, Azure, GCP, and OpenStack.

---

## 📋 Table of Contents

| # | Practical | Platform | Key Concepts |
|---|---|---|---|
| 01 | [Introduction to Cloud Platforms](./Practical_01_Introduction_to_Cloud_Platforms.md) | AWS + Azure + GCP | Service models, Pricing calculators, Console navigation |
| 02 | [Launch Your First EC2 Instance](./Practical_02_Launch_EC2_Instance.md) | AWS | EC2, AMI, Key Pairs, Security Groups, SSH |
| 03 | [Set Up a VPC](./Practical_03_Setup_VPC.md) | AWS | VPC, Subnets, IGW, NAT Gateway, Route Tables |
| 04 | [Auto Scaling and Load Balancing](./Practical_04_Auto_Scaling_Load_Balancing.md) | AWS | ASG, Launch Templates, ALB, Scaling Policies |
| 05 | [Deploy a Static Website](./Practical_05_Static_Website_Hosting.md) | AWS + Azure + GCP | S3, Blob Storage, Cloud Storage, CDN |
| 06 | [Monitor with CloudWatch](./Practical_06_CloudWatch_Monitoring.md) | AWS | CloudWatch Metrics, Alarms, SNS, Dashboards |
| 07 | [Install OpenStack](./Practical_07_Install_OpenStack.md) | OpenStack | DevStack, MicroStack, OpenStack Architecture |
| 08 | [First OpenStack Instance](./Practical_08_OpenStack_First_Instance.md) | OpenStack | Nova, Glance, Flavors, Horizon, Projects |
| 09 | [OpenStack Networking](./Practical_09_OpenStack_Networking.md) | OpenStack | Neutron, Router, Floating IPs, Network Topology |
| 10 | [Cloud Security](./Practical_10_Cloud_Security.md) | AWS + OpenStack | IAM, Least Privilege, Encryption, Firewall Rules |

---

## 🗺️ Learning Path

```
Phase 1 — Cloud Fundamentals (Practicals 1–2)
  └── Understand cloud platforms and launch your first VM

Phase 2 — AWS Networking & Scalability (Practicals 3–4)
  └── Build production-grade network architecture with auto scaling

Phase 3 — Cloud Services (Practicals 5–6)
  └── Host websites and implement monitoring

Phase 4 — Private Cloud with OpenStack (Practicals 7–9)
  └── Build and manage your own cloud infrastructure

Phase 5 — Cloud Security (Practical 10)
  └── Secure everything with IAM, encryption, and firewalls
```

---

## 🔑 AWS to OpenStack Quick Reference

| Concept | AWS | OpenStack |
|---|---|---|
| Virtual Machine | EC2 | Nova Instance |
| Machine Image | AMI | Glance Image |
| Instance Size | Instance Type | Flavor |
| Virtual Network | VPC | Neutron Network |
| Subnet | Subnet | Neutron Subnet |
| Route Table | Route Table | Neutron Router |
| Public IP | Elastic IP | Floating IP |
| Firewall | Security Group | Security Group |
| Object Storage | S3 | Swift |
| Block Storage | EBS | Cinder |
| Identity | IAM | Keystone |
| Dashboard | Console | Horizon |
| Monitoring | CloudWatch | Ceilometer |
| Templates | CloudFormation | Heat |

---

## ⚙️ Prerequisites

- Computer with internet access and a modern browser
- Linux/Mac terminal OR Windows with WSL/PuTTY
- Credit/debit card (for cloud account creation — free tier, no charges if followed correctly)
- For OpenStack: A machine with 8GB+ RAM, 4+ cores, 50GB disk
- Basic Linux command-line knowledge

---

## ⚠️ Cost Management Tips

1. **Always set billing alerts** before doing anything else (AWS: $5 budget alert)
2. **Stop/terminate** EC2 instances and NAT Gateways when not in use
3. **Free tier limits** are per account, not per region — keep track at: https://console.aws.amazon.com/billing/home#/freetier
4. **DevStack** is completely free (runs on your own machine)
5. Use **us-east-1** (N. Virginia) for AWS practicals — best free tier support

---

*Prepared for Cloud Computing Lab — Academic Year 2024-25*
